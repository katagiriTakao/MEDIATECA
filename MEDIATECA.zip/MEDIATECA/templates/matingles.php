<?php

include ('menu.php');


echo "
		<center>
			<div class='card' style='width:600px;'>
				<div class='card-image waves-effect waves-block waves-light'>
				  <img src='http://contenidos.enter.co/custom/uploads/2015/07/ingles_1000.jpg'>
				</div>
				<div class='card-content card-panel hoverable'>
				  <span class='card-title grey-text text-darken-4'>INGLÉS</span>
				  <span class='card-title'  grey-text text-darken-4'>Materiales de Apoyo</span>
				  <p><a href='http://www.mediateca.prepa6.unam.mx/wp-content/uploads/2016/09/LISTENING-ACTIVITY-INTERMEDIO.pdf'>LISTENING  ACTIVITY – NIVEL INTERMEDIO</a></p>
				  <p><a href='http://www.mediateca.prepa6.unam.mx/wp-content/uploads/2016/11/Podcast_Balderas.pdf'>PODCAST</a></p>
				  <p><a href='http://www.mediateca.prepa6.unam.mx/wp-content/uploads/2016/11/CNN-students_Podcast.pdf'>PODCAST 2</a></p>
				</div>
				</div>
				</div>
			</div>	
				
		</center>";
	//--Footer-----------------------------------------------------------------------------------------------------------------------------------------------------------------> 
							echo	"<footer class='white page-footer'>
											  <div class='blue-grey darken-4 footer-copyright'>
												<div class='container white-text'>
												© 2017 Copyright Text
												<a class='white-text right' href='http://www.prepa6.unam.mx'>Preparatoria 6 Antonio Caso</a>
												</div>
											  </div>
									 </footer>";	
					


?>
		





















