<?php

	include ('menu.php');
	//------------------------------------------- cartas de alumnos-------------------------------------------------->
					
echo 
	"<center>
		<div class='row'>
			<div class='col s12 m6 offset-m3'>
			  <div class='card card-panel hoverable'>
				<div class='card-image'>
				  <img src='http://www.mediateca.prepa6.unam.mx/wp-content/uploads/2017/01/JEA.jpg'>
				  <span class='card-title'>Jovenes en Acción</span>
				</div>
				<div class='card-content'>
				  <p>Demuestra el talento que tienes y presenta un proyecto interesante en beneficio de todos.</p>
				</div>
				<div class='card-action'>
				  <a href='http://www.mediateca.prepa6.unam.mx/wp-content/uploads/2017/01/JeA-esp.pdf'>Jovenes en Accón</a>
				</div>
			  </div>
			</div>
		  </div>
	</center>";	
echo"<center>
		<div class='row'>
			<div class='col s12 m6 offset-m3'>
			  <div class='card '>
				<div class='card-image'>
				  <img src='http://www.mediateca.prepa6.unam.mx/wp-content/uploads/2017/01/GoetheIN.png'>
				  <span class='card-title'>Becas de Aleman</span>
				</div>
				<div class='card-content'>
				  <p>Para un mejor aprendizaje del idioma aleman esta oportunidad es para ti!!</p>
				</div>
				<div class='card-action'>
				  <a href='https://www.goethe.de/ins/mx/es/spr/eng/convocatoria-de-becas-2017-201.html'>Becas Alemania</a>
				</div>
			  </div>
			</div>
		  </div>
	</center>";			
	//--Footer-----------------------------------------------------------------------------------------------------------------------------------------------------------------> 
							echo	"<footer class='white page-footer'>
											  <div class='blue-grey darken-4 footer-copyright'>
												<div class='container white-text'>
												© 2017 Copyright Text
												<a class='white-text right' href='http://www.prepa6.unam.mx'>Preparatoria 6 Antonio Caso</a>
												</div>
											  </div>
									 </footer>";				
					
	//----------------------------------------------------------------------------------------------------------------->				
					echo	"<script type='text/javascript' src='https://code.jquery.com/jquery-2.1.1.min.js'></script>
							<script type='text/javascript' src='../materialize/js/materialize.min.js'></script>";
					echo	"<script>
							
						</script>";



?>