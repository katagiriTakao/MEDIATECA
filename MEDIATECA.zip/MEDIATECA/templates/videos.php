<?php 

include('menu.php');
echo "
	<!DOCTYPE html> 
	<html lang='es'>
		<head>	
			
		</head>";
echo	"<body>";
		
			echo " 
				<div class='container'>
					<div class='row'>
						<div class='col s12'>
							<div class='row'>
							
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/186493405' frameborder='0' allowfullscreen></iframe>
								</div>			
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/186499808' frameborder='0' allowfullscreen></iframe>
								</div>	
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/186510699' frameborder='0' allowfullscreen></iframe>
								</div>
							</div>
							<div class='row'>
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/187226918' frameborder='0' allowfullscreen></iframe>
								</div>
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/187232925' frameborder='0' allowfullscreen></iframe>
								</div>
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/187240585' frameborder='0' allowfullscreen></iframe>
								</div>
							<div class='row'>	
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/187241406' frameborder='0' allowfullscreen></iframe>
								</div>
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/187241638' frameborder='0' allowfullscreen></iframe>
								</div>
								<div class='card col m4'>
									<iframe src='https://player.vimeo.com/video/187241922' frameborder='0' allowfullscreen></iframe>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	";
		//<div class='fancybox-inner' style='overflow: scroll; width: 800px; height: 533px;'><iframe id='fancybox-frame1497589277557' name='fancybox-frame1497589277557' class='fancybox-iframe' frameborder='0' vspace='0' hspace='0' webkitallowfullscreen='' mozallowfullscreen='' allowfullscreen='' scrolling='auto' src='http://www.youtube.com/embed/7VqOPlupZRg?rel=0&amp;autoplay=1'></iframe></div>";
		//--Footer-----------------------------------------------------------------------------------------------------------------------------------------------------------------> 
							echo	"<footer class='white page-footer'>
											  <div class='blue-grey darken-4 footer-copyright'>
												<div class='container white-text'>
												© 2017 Copyright Text
												<a class='white-text right' href='http://www.prepa6.unam.mx'>Preparatoria 6 Antonio Caso</a>
												</div>
											  </div>
									 </footer>";
		//--------------------------------------------------------------------------------------------------------
									 
		echo "	<script type='text/javascript' src='https://code.jquery.com/jquery-2.1.1.min.js'></script>
				<script type='text/javascript' src='../materialize/js/materialize.min.js'></script>";
		echo	"<script>
				
				</script>";  
        
		
echo	"</body>";
echo "</html>";	

?>
