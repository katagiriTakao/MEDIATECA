<?php

	include ('menu.php');
	//------------------------------------------- cartas de alumnos-------------------------------------------------->
					
echo 
	"<center>
		<div class='row'>
			<div class='col s12 m6 offset-m3'>
			  <div class='card card-panel hoverable'>
				<div class='card-image'>
				  <img src='../resources/images/comexus.jpg'>
				</div>
				<div class='card-content'>
				  <p>COMEXUS</p>
				</div>
				<div class='card-action'>
				  <a href='http://www.comexus.org.mx/convocatoria_SEMS.html' target='blank'>ENTRA</a>
				</div>
			  </div>
			</div>
		  </div>
	</center>";	
echo"<center>
		<div class='row'>
			<div class='col s12 m6 offset-m3'>
			  <div class='card card-panel hoverable'>
				<div class='card-image'>
				  <img src='https://pub.teachwithepi.com/svg/recruitment-partners.svg'>
				 
				</div>
				<div class='card-content'>
				  <p>Educational Partners International, LLC (EPI) </p>
				</div>
				<div class='card-action'>
				  <a href='https://teachwithepi.com/' target='blank'>ENTRA</a>
				</div>
			  </div>
			</div>
		  </div>
	</center>";		
/*	

	INSTRUCCIONES TEMPORALES PARA INGRESAR BECAS PARA DOCENTES EN LA PÁGINA
	echo"<center>
		<div class='row'>
			<div class='col s12 m6 offset-m3'>
			  <div class='card'>
				<div class='card-image'>
				  <img src='AQUI SE COLOCA LA FUENTE DE LA IMAGEN DE LA TARJETA QU ESE UTILIZARÁ EN LA PÁGINA'>
				 
				</div>
				<div class='card-content'>
				  <p>AQUI SE PONE EL NOMBRE DE LA BECA Y/O DE LA ORGANIZACIÓN </p>
				</div>
				<div class='card-action'>
				  <a href='ESTE ES EL ENLACE DE LA PÁGINA DE DE LA BECA'>ENTRA</a>
				</div>
			  </div>
			</div>
		  </div>
	</center>";			*/	
	//--Footer-----------------------------------------------------------------------------------------------------------------------------------------------------------------> 
							echo	"<footer class='white page-footer'>
											  <div class='blue-grey darken-4 footer-copyright'>
												<div class='container white-text'>
												© 2017 Copyright Text
												<a class='white-text right' href='http://www.prepa6.unam.mx'>Preparatoria 6 Antonio Caso</a>
												</div>
											  </div>
									 </footer>";	
						
					
					
					
					
					
	//----------------------------------------------------------------------------------------------------------------->				
					echo	"<script type='text/javascript' src='https://code.jquery.com/jquery-2.1.1.min.js'></script>
							<script type='text/javascript' src='../materialize/js/materialize.min.js'></script>";
					echo	"<script>
							
						</script>"
						
?>						