<?php

include ('menu.php');

	
echo  "
		<center>
			<div class='card' style='width:600px;'>
				<div class='card-image waves-effect waves-block waves-light'>
				  <img src='https://es.babbel.com/assets/static/img/clases-de-frances.jpg'>
				</div>
				<div class='card-content card-panel hoverable'>
				  <span class='card-title grey-text text-darken-4'>FRANCES</span>
				  <span class='card-title grey-text text-darken-4'>Materiales de Apoyo</span>
				  <p><a href='http://www.aulafacil.com/Franceslectura/Curso/Lecc-2.htm'>Fichas de trabajo de francés</a></p>
				</div>
			</div>	
		</center>";		
	//--Footer-----------------------------------------------------------------------------------------------------------------------------------------------------------------> 
	echo	"<footer class='white page-footer'>
											  <div class='blue-grey darken-4 footer-copyright'>
												<div class='container white-text'>
												© 2017 Copyright Text
												<a class='white-text right' href='http://www.prepa6.unam.mx'>Preparatoria 6 Antonio Caso</a>
												</div>
											  </div>
									 </footer>";	
					


?>
 